var struct__NVDRS__PROFILE__V1 =
[
    [ "gpuSupport", "struct__NVDRS__PROFILE__V1.html#a2bc6d436c953b83424909036021cce73", null ],
    [ "isPredefined", "struct__NVDRS__PROFILE__V1.html#a14adbbbf7158d9995def6d8a6f449e8d", null ],
    [ "numOfApps", "struct__NVDRS__PROFILE__V1.html#a27348cd5aa64fbf1cb1005af28811597", null ],
    [ "numOfSettings", "struct__NVDRS__PROFILE__V1.html#a2af9b8f5304a5e330c6160617c91572d", null ],
    [ "profileName", "struct__NVDRS__PROFILE__V1.html#af1a046519790db5a4378349bba0d45cd", null ],
    [ "version", "struct__NVDRS__PROFILE__V1.html#a121df2fa312048bb12a15f02fe1cb504", null ]
];