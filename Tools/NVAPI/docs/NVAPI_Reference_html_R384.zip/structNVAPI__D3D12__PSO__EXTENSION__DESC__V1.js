var structNVAPI__D3D12__PSO__EXTENSION__DESC__V1 =
[
    [ "baseVersion", "structNVAPI__D3D12__PSO__EXTENSION__DESC__V1.html#aa66ede6ec0c37ff842036559bdc3815d", null ],
    [ "psoExtension", "structNVAPI__D3D12__PSO__EXTENSION__DESC__V1.html#af31d6fafb57a5f9a52576d0356d3a4f6", null ]
];