var struct__NVVIOCHANNELSTATUS =
[
    [ "bitsPerComponent", "struct__NVVIOCHANNELSTATUS.html#ae8f948a843714a1ac5060fa2ecc71776", null ],
    [ "colorSpace", "struct__NVVIOCHANNELSTATUS.html#a08c81cafc82976119847bd27222e42ab", null ],
    [ "linkID", "struct__NVVIOCHANNELSTATUS.html#a0220670f546a01d2b692e2a333d70da6", null ],
    [ "samplingFormat", "struct__NVVIOCHANNELSTATUS.html#a6f8992cdb6291889e80989bedb686645", null ],
    [ "signalFormat", "struct__NVVIOCHANNELSTATUS.html#a3b132f8905cb6a273b07762960948bbc", null ],
    [ "smpte352", "struct__NVVIOCHANNELSTATUS.html#a77af8b3831249aa24984420ed21672fa", null ]
];