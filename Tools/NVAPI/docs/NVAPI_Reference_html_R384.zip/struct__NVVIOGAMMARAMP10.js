var struct__NVVIOGAMMARAMP10 =
[
    [ "uBlue", "struct__NVVIOGAMMARAMP10.html#a2bb3efbdaf3b8703ea029e7dbb454120", null ],
    [ "uGreen", "struct__NVVIOGAMMARAMP10.html#a8ebfa86f93a3e8955068ef86b6f68fd5", null ],
    [ "uRed", "struct__NVVIOGAMMARAMP10.html#a57c691dbd35501b1d0e70b4ee690e6ac", null ]
];