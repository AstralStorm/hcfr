var structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V3 =
[
    [ "UseSpecificShaderExt", "structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V3.html#a8f6609aa9034f61317e7c1b786585432", null ]
];