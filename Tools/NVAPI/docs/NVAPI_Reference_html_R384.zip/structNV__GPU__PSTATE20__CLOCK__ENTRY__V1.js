var structNV__GPU__PSTATE20__CLOCK__ENTRY__V1 =
[
    [ "bIsEditable", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a11f2a8619d842a69ceb6989cfb7aa8cd", null ],
    [ "data", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#ace6997db408292222125c57c3c2f043e", null ],
    [ "domainId", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a6932faeeee7a0550802664854a181c9c", null ],
    [ "domainId", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#ade11cafe352438aa876823ff9637d204", null ],
    [ "freq_kHz", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a49cadb0b15e0172360d7df7e4c5ee8ea", null ],
    [ "freqDelta_kHz", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#af9d5f569fe349035b4dbad6e2127f4ec", null ],
    [ "maxFreq_kHz", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a39011c2c0fa6290fbd4a9a55da7ced98", null ],
    [ "maxVoltage_uV", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a6c221a5afd40abe4fbd359dae611c47b", null ],
    [ "minFreq_kHz", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a859529efb9c0c9678fbe744ace906723", null ],
    [ "minVoltage_uV", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#ad4d78084c70c38c9182e91ad4f3f2c4a", null ],
    [ "range", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a78ffddcf78830afe5a0bee8175203b2c", null ],
    [ "reserved", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#a532389908fa770969801365ecfc03fb7", null ],
    [ "single", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#aadcfd23e42506d6183dd8a1636ce7459", null ],
    [ "typeId", "structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#aba67fa09ff2b7024b9b5b9806750d3a8", null ]
];