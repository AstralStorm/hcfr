var group__dxapi =
[
    [ "DirectX Interface", "group__dx.html", "group__dx" ],
    [ "DirectX Video Control", "group__dxvidcontrol.html", "group__dxvidcontrol" ]
];