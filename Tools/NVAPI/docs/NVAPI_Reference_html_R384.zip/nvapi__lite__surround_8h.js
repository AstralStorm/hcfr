var nvapi__lite__surround_8h =
[
    [ "NV_MOSAIC_MAX_DISPLAYS", "nvapi__lite__surround_8h.html#aa176506115b104c05f8ac09bb882b8ff", null ],
    [ "NvAPI_DISP_GetGDIPrimaryDisplayId", "group__dispcontrol.html#ga0319557a593f6fbbfbd435f009b6aa40", null ],
    [ "NvAPI_Mosaic_GetDisplayViewportsByResolution", "group__mosaicapi.html#gaa42f70364b56ba5206f1e8c864e368f6", null ]
];