var structNV__DISPLAY__PATH__INFO =
[
    [ "count", "structNV__DISPLAY__PATH__INFO.html#a35296bba0b4a6ad25752334425506b32", null ],
    [ "path", "structNV__DISPLAY__PATH__INFO.html#a8a0af7c634faa7e3ad22fb262d734670", null ],
    [ "version", "structNV__DISPLAY__PATH__INFO.html#a24e6f8c79291060a87cf59d2ab214d45", null ]
];