var struct__NVVIOOUTPUTSTATUS =
[
    [ "compSyncIn", "struct__NVVIOOUTPUTSTATUS.html#aa1736ab068191f4e8b09331672e59341", null ],
    [ "dataIntegrityCheckEnabled", "struct__NVVIOOUTPUTSTATUS.html#a9df87fd0cd31357c8e6e5426e7e7bb79", null ],
    [ "dataIntegrityCheckErrorCount", "struct__NVVIOOUTPUTSTATUS.html#ae19fe170d8a1164cd1ddd66fbe8d456a", null ],
    [ "dataIntegrityCheckFailed", "struct__NVVIOOUTPUTSTATUS.html#a053f3dfa13be6c6fcd5cc15193cac811", null ],
    [ "frameLockEnable", "struct__NVVIOOUTPUTSTATUS.html#ada379a0b48ae0d7d41ea8c187c92034e", null ],
    [ "outputVideoLocked", "struct__NVVIOOUTPUTSTATUS.html#ae27ff8cef54cbd58d8fedd79ffbee474", null ],
    [ "sdiSyncIn", "struct__NVVIOOUTPUTSTATUS.html#aedbb3bdf6d092461c542572d80cf00e6", null ],
    [ "syncEnable", "struct__NVVIOOUTPUTSTATUS.html#afa441517f644d658192adbb88bc04f60", null ],
    [ "syncFormat", "struct__NVVIOOUTPUTSTATUS.html#a424faa60daf4bee97a28f0edfa9809c8", null ],
    [ "syncSource", "struct__NVVIOOUTPUTSTATUS.html#a61a1948c8dff4214b6b04799c877195a", null ],
    [ "uPowerOn", "struct__NVVIOOUTPUTSTATUS.html#aabb94426b288a68b493792cb841d0525", null ],
    [ "uSyncSourceLocked", "struct__NVVIOOUTPUTSTATUS.html#a062fd0a44ce9d5deef880c63ae4f5b7d", null ],
    [ "vid1Out", "struct__NVVIOOUTPUTSTATUS.html#a0ff32eb9adecdb400fb7b5e471430912", null ],
    [ "vid2Out", "struct__NVVIOOUTPUTSTATUS.html#a737bfed3d93612e13e5908b534b56c5d", null ]
];