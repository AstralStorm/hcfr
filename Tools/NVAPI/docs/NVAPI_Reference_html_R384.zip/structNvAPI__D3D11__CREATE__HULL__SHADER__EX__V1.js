var structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V1 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V1.html#ac4080d7054d73944e0f2a06a33a9e838", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V1.html#aa26effa057cb8ef81dd249ed0b672996", null ],
    [ "UseWithFastGS", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V1.html#a92cf8a23c3be28cfa5f70e1003939f00", null ],
    [ "version", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V1.html#a7943ee00ae29c8e1c7809d8492f708d9", null ]
];