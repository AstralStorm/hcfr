var structNV__INFOFRAME__PROPERTY =
[
    [ "blackList", "structNV__INFOFRAME__PROPERTY.html#a14691d57309c2343dd3b7526d535970c", null ],
    [ "length", "structNV__INFOFRAME__PROPERTY.html#a68b18d18b279cd25d65350191e8a6432", null ],
    [ "mode", "structNV__INFOFRAME__PROPERTY.html#a36c84488c7d7837dc80f9fb22c312e51", null ],
    [ "reserved", "structNV__INFOFRAME__PROPERTY.html#ac21827cd2774fc10a84c8a6b446fe9fe", null ],
    [ "version", "structNV__INFOFRAME__PROPERTY.html#ac592b43b4aaf4c3fdfedd73d07ead41d", null ]
];