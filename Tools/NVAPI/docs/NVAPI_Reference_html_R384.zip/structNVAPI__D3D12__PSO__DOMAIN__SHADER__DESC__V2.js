var structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V2 =
[
    [ "UseWithFastGS", "structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V2.html#afc7ac38866bca78c2e57700e672dcc7a", null ]
];