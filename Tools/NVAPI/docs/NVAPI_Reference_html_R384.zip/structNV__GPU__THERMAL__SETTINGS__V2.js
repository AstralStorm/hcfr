var structNV__GPU__THERMAL__SETTINGS__V2 =
[
    [ "controller", "structNV__GPU__THERMAL__SETTINGS__V2.html#aed662098a3514b0a6d6c28229e949fd6", null ],
    [ "count", "structNV__GPU__THERMAL__SETTINGS__V2.html#aa5fd52a6d7426c7b1fec035b8e39d3d1", null ],
    [ "currentTemp", "structNV__GPU__THERMAL__SETTINGS__V2.html#ac4daaeb8bdb6bb3ac3f074e1c21bebd7", null ],
    [ "defaultMaxTemp", "structNV__GPU__THERMAL__SETTINGS__V2.html#a2fd4338af179b274c1ae7a9c239cf881", null ],
    [ "defaultMinTemp", "structNV__GPU__THERMAL__SETTINGS__V2.html#a75110d87a03a96bbdfffb9ae8e8e757e", null ],
    [ "sensor", "structNV__GPU__THERMAL__SETTINGS__V2.html#a76ac6f8c1485047dfe717a3f2d296be5", null ],
    [ "target", "structNV__GPU__THERMAL__SETTINGS__V2.html#a18cb5fb17d67c950e32e99dd9e5b3c83", null ],
    [ "version", "structNV__GPU__THERMAL__SETTINGS__V2.html#a040403dcc71bd3aa8a348b4069cb9e0b", null ]
];