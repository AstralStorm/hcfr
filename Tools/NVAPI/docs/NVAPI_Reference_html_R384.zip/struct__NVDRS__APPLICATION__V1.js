var struct__NVDRS__APPLICATION__V1 =
[
    [ "appName", "struct__NVDRS__APPLICATION__V1.html#a3b34b6bdae4086076e9f9a45da48dbd4", null ],
    [ "isPredefined", "struct__NVDRS__APPLICATION__V1.html#a5d78e62be3b9a90101f2c32bcb226259", null ],
    [ "launcher", "struct__NVDRS__APPLICATION__V1.html#a6e1a9e69daecce24e32c98a1aa95b0f9", null ],
    [ "userFriendlyName", "struct__NVDRS__APPLICATION__V1.html#a33e0a8547bd9d409703e7f5065bb6a9a", null ],
    [ "version", "struct__NVDRS__APPLICATION__V1.html#ab12e8eb0a0bbfba8122066cef4e379aa", null ]
];