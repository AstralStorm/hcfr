var structNV__DISPLAY__DRIVER__MEMORY__INFO__V2 =
[
    [ "availableDedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V2.html#ae94b883a1479db994bb58088266c14e9", null ],
    [ "curAvailableDedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V2.html#ad9c5c4ddce482e8d4d0517b67268fa63", null ],
    [ "dedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V2.html#a28263ab8cf7716d820a5483589b3e673", null ],
    [ "sharedSystemMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V2.html#ae10877f33d2e4490e2c87876a34a3d2e", null ],
    [ "systemVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V2.html#a6aba09ebf2a45a67bb49795a51139f28", null ],
    [ "version", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V2.html#a9bf70379561c4c8085a7ec863945b593", null ]
];