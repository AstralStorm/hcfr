var struct__NVDRS__SETTING__V1 =
[
    [ "binaryCurrentValue", "struct__NVDRS__SETTING__V1.html#a0450094ec60229f1c51c64cea2217aba", null ],
    [ "binaryPredefinedValue", "struct__NVDRS__SETTING__V1.html#a09227f4f7f81c5972ba03095a73ebc20", null ],
    [ "isCurrentPredefined", "struct__NVDRS__SETTING__V1.html#abe02485a453def5560a2d9d114e75a93", null ],
    [ "isPredefinedValid", "struct__NVDRS__SETTING__V1.html#ab26fd99a57a22475a525f76ca761660b", null ],
    [ "settingId", "struct__NVDRS__SETTING__V1.html#a7b1485548903721749b7ad65e608e6dc", null ],
    [ "settingLocation", "struct__NVDRS__SETTING__V1.html#ad272e40aec54d48679050ab507dfe706", null ],
    [ "settingName", "struct__NVDRS__SETTING__V1.html#acda90b0c9e1d41353cfef6224f9ad07c", null ],
    [ "settingType", "struct__NVDRS__SETTING__V1.html#ab1e01497fc4a5dce40881d639f0442fa", null ],
    [ "u32CurrentValue", "struct__NVDRS__SETTING__V1.html#a64a730602dded7409fd25be661f5e619", null ],
    [ "u32PredefinedValue", "struct__NVDRS__SETTING__V1.html#a549a2a24058eb9ef76f90a99d07ebe30", null ],
    [ "version", "struct__NVDRS__SETTING__V1.html#aee1eb112b118e1e361846029f2e97a00", null ],
    [ "wszCurrentValue", "struct__NVDRS__SETTING__V1.html#a58ad5999ab1f2d4de93045e11faa4992", null ],
    [ "wszPredefinedValue", "struct__NVDRS__SETTING__V1.html#a1648ab4c1e452cd67627e65887a5f72b", null ]
];