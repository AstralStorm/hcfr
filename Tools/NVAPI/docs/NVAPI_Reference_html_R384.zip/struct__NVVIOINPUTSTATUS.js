var struct__NVVIOINPUTSTATUS =
[
    [ "captureStatus", "struct__NVVIOINPUTSTATUS.html#a49b83eb2c0ee97277c6aaef0afe69e7c", null ],
    [ "vidIn", "struct__NVVIOINPUTSTATUS.html#a80b88ee3da593c952c4eb1da18d01f20", null ]
];