var structNV__I2C__INFO__V2 =
[
    [ "bIsDDCPort", "structNV__I2C__INFO__V2.html#a12cd753fdf33e0d68b1c804f2a06a97a", null ],
    [ "cbSize", "structNV__I2C__INFO__V2.html#acb15a8331cabc2ba237d54a6d29d34cf", null ],
    [ "displayMask", "structNV__I2C__INFO__V2.html#ace19af100b85cf8de83ea411ac2d2deb", null ],
    [ "i2cDevAddress", "structNV__I2C__INFO__V2.html#ae9f6cacf61e358796855418f016faaf1", null ],
    [ "i2cSpeed", "structNV__I2C__INFO__V2.html#a16796f2f3142f26644637436d971c020", null ],
    [ "i2cSpeedKhz", "structNV__I2C__INFO__V2.html#a0a099c7e1592d562a3a909943caf6c34", null ],
    [ "pbData", "structNV__I2C__INFO__V2.html#ad494692db2e82e2006881578e34f8595", null ],
    [ "pbI2cRegAddress", "structNV__I2C__INFO__V2.html#a5ca6f8e316d155623883ed5b2c775e6d", null ],
    [ "regAddrSize", "structNV__I2C__INFO__V2.html#a5f5fbdf367855c6b50018ba5c5691f47", null ],
    [ "version", "structNV__I2C__INFO__V2.html#ab475450af746e454d03451a05f63478b", null ]
];