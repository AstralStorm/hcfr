var structNVAPI__D3D12__PSO__CREATE__FASTGS__EXPLICIT__DESC__V1 =
[
    [ "flags", "structNVAPI__D3D12__PSO__CREATE__FASTGS__EXPLICIT__DESC__V1.html#af93e053d62a70e6d5d82b67c0368295b", null ],
    [ "pCoordinateSwizzling", "structNVAPI__D3D12__PSO__CREATE__FASTGS__EXPLICIT__DESC__V1.html#acb8ee13c0425cbf04cdc91e4e696a395", null ],
    [ "version", "structNVAPI__D3D12__PSO__CREATE__FASTGS__EXPLICIT__DESC__V1.html#a1176839e58a3a1981ffbccee4624aedd", null ]
];