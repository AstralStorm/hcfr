var structNV__GPU__CLOCK__FREQUENCIES__V2 =
[
    [ "bIsPresent", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#aa7c9a2047ad9297d4b2608b545bf863c", null ],
    [ "ClockType", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#a1aa5c52846603c5e20a70b5c06742df9", null ],
    [ "domain", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#a3abfb9b8736231d75703ef65af3496e4", null ],
    [ "frequency", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#a90def05453232f2a9a9e7c98ce4c4f5e", null ],
    [ "reserved", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#af8ac8e7f634d30aace929e669f93e523", null ],
    [ "reserved1", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#a8a4a37dc36959f3ffca2865588d70f25", null ],
    [ "version", "structNV__GPU__CLOCK__FREQUENCIES__V2.html#ac6844083b6e5f03ca294e6f769c5ef23", null ]
];