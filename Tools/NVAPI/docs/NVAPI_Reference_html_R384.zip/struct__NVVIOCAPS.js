var struct__NVVIOCAPS =
[
    [ "adapterCaps", "struct__NVVIOCAPS.html#a2c51ba6830b72be2620cfc0a0bc1d952", null ],
    [ "adapterClass", "struct__NVVIOCAPS.html#a12808b2d9084ff27bb3bbe111b3d44dc", null ],
    [ "adapterName", "struct__NVVIOCAPS.html#ac65e5539b65a2e4ba58f2f5c91f045db", null ],
    [ "boardID", "struct__NVVIOCAPS.html#a73d18a8dc20fc306ab58457a72342cfe", null ],
    [ "dipSwitch", "struct__NVVIOCAPS.html#ada56381d6832d93e4c14fcf1bc62f9b2", null ],
    [ "dipSwitchReserved", "struct__NVVIOCAPS.html#afe8e587bd97db95ceae41c42ed73e833", null ],
    [ "driver", "struct__NVVIOCAPS.html#a198265c16612212e5b11ddf679b667cf", null ],
    [ "firmWare", "struct__NVVIOCAPS.html#a37cc013ec01380dca9c5d3dc1f23e7a6", null ],
    [ "majorVersion", "struct__NVVIOCAPS.html#a16ca228aaef396ab382e4f0907f6e96b", null ],
    [ "minorVersion", "struct__NVVIOCAPS.html#a60605f9b61a03d83ead537daacdc3955", null ],
    [ "ownerId", "struct__NVVIOCAPS.html#a3f596999cf163e5adc221cdd85919e3f", null ],
    [ "ownerType", "struct__NVVIOCAPS.html#a14188e4b56518770e3a439adb3abc5fc", null ],
    [ "version", "struct__NVVIOCAPS.html#ae83fa39b8f29176c5e09cae9a3daa696", null ]
];