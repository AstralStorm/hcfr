var structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V1 =
[
    [ "NumCustomSemantics", "structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V1.html#acda5e1625f390992115a3fc7f7970d03", null ],
    [ "pCustomSemantics", "structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V1.html#abe3b7987edf1615a98158ff395220696", null ],
    [ "UseWithFastGS", "structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V1.html#acf207c23c22c7d31aca9e0bfdccc69a4", null ],
    [ "version", "structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V1.html#a44f254d88d5c22fc404b46ae5dc7f159", null ]
];