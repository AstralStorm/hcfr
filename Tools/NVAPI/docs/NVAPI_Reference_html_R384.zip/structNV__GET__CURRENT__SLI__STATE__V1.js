var structNV__GET__CURRENT__SLI__STATE__V1 =
[
    [ "bIsCurAFRGroupNew", "structNV__GET__CURRENT__SLI__STATE__V1.html#ae985de0b10491800123776903139d12b", null ],
    [ "currentAFRIndex", "structNV__GET__CURRENT__SLI__STATE__V1.html#a134c72b727f4f1f0550823e73b9ba65f", null ],
    [ "maxNumAFRGroups", "structNV__GET__CURRENT__SLI__STATE__V1.html#a4ba93f81b2df9100026c2a489c7bf060", null ],
    [ "nextFrameAFRIndex", "structNV__GET__CURRENT__SLI__STATE__V1.html#a2fcf7710a5256e8c31b96bf162b14185", null ],
    [ "numAFRGroups", "structNV__GET__CURRENT__SLI__STATE__V1.html#a632f12b81b8746a9e08599ceb7e23fa4", null ],
    [ "previousFrameAFRIndex", "structNV__GET__CURRENT__SLI__STATE__V1.html#a47f81c9ce074dbc9c1f8dc732814acaf", null ],
    [ "version", "structNV__GET__CURRENT__SLI__STATE__V1.html#ae25e248e41b96bd292ab7f93be7bf7cc", null ]
];