var struct__NVVIOCONFIG__V1 =
[
    [ "fields", "struct__NVVIOCONFIG__V1.html#a0df6ce7c76986edb7795fdac3753a780", null ],
    [ "inConfig", "struct__NVVIOCONFIG__V1.html#a03ae90e0316de07780f21fee1f7fdd02", null ],
    [ "nvvioConfigType", "struct__NVVIOCONFIG__V1.html#a32185c579945f9eb4a15dcae736133b2", null ],
    [ "outConfig", "struct__NVVIOCONFIG__V1.html#a4546b1baed61c772031b5a038f488312", null ],
    [ "version", "struct__NVVIOCONFIG__V1.html#a041aadd190cd0a5f879416cf1c2bd99a", null ],
    [ "vioConfig", "struct__NVVIOCONFIG__V1.html#a8d758278a0234d2a3df36c634ff05b97", null ]
];