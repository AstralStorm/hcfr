var structNV__DISPLAY__DRIVER__VERSION =
[
    [ "bldChangeListNum", "structNV__DISPLAY__DRIVER__VERSION.html#ae3edc654cd90e26a640cb7a3ddabdc3a", null ],
    [ "drvVersion", "structNV__DISPLAY__DRIVER__VERSION.html#ab8e91235184fe56336cbaab076576ae6", null ],
    [ "szAdapterString", "structNV__DISPLAY__DRIVER__VERSION.html#a2cbc96801aafba57ab6d3997caa87aef", null ],
    [ "szBuildBranchString", "structNV__DISPLAY__DRIVER__VERSION.html#abf80b8500f617c639f1610298970e6c0", null ],
    [ "version", "structNV__DISPLAY__DRIVER__VERSION.html#ae42539bd8375fd1f9503548377b7d781", null ]
];