var struct__NVVIOINPUTCONFIG =
[
    [ "bTestMode", "struct__NVVIOINPUTCONFIG.html#a3d1a2648ddcc7a8d2e21f263512e8810", null ],
    [ "numRawCaptureImages", "struct__NVVIOINPUTCONFIG.html#a76361c437e3f5b5bafed1866411f35e4", null ],
    [ "numStreams", "struct__NVVIOINPUTCONFIG.html#a930adde7a5bad72d2c8acab4baa5cb05", null ],
    [ "signalFormat", "struct__NVVIOINPUTCONFIG.html#a482b617394e85df3719efc5f79d79cc7", null ],
    [ "streams", "struct__NVVIOINPUTCONFIG.html#a48732bef406062f8f6da84a9ac393968", null ]
];