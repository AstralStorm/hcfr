var struct__NVDRS__SETTING__VALUES =
[
    [ "binaryDefaultValue", "struct__NVDRS__SETTING__VALUES.html#a6167af1157a095cd8677cb9cc5115fbd", null ],
    [ "binaryValue", "struct__NVDRS__SETTING__VALUES.html#a87b2ee240561ea123d7d8c6ab435c387", null ],
    [ "numSettingValues", "struct__NVDRS__SETTING__VALUES.html#a5e62063ab7571070f9893706b88dbc00", null ],
    [ "settingType", "struct__NVDRS__SETTING__VALUES.html#ac3c21f6f74ef805b6d741d2e24bd2ea0", null ],
    [ "settingValues", "struct__NVDRS__SETTING__VALUES.html#af23b939ca1e18217622f175b17e982ff", null ],
    [ "u32DefaultValue", "struct__NVDRS__SETTING__VALUES.html#a9145138952a708b3f8d6207310a589e7", null ],
    [ "u32Value", "struct__NVDRS__SETTING__VALUES.html#a644707e439359e17bfbc19e8a855b5d9", null ],
    [ "version", "struct__NVDRS__SETTING__VALUES.html#a8584d363ea6ee65a4f6aa1a6a71ae6f8", null ],
    [ "wszDefaultValue", "struct__NVDRS__SETTING__VALUES.html#aab2b4812a28e8f329a3f324e24857490", null ],
    [ "wszValue", "struct__NVDRS__SETTING__VALUES.html#a69476141ad417f0024ad7039f6d29a01", null ]
];