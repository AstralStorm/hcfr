var structNV__MOSAIC__TOPO__BRIEF =
[
    [ "enabled", "structNV__MOSAIC__TOPO__BRIEF.html#a0c35ffc94bc867ebd259e803c06e2806", null ],
    [ "isPossible", "structNV__MOSAIC__TOPO__BRIEF.html#ad87ba0790e221d27a997ad3b2d95522d", null ],
    [ "topo", "structNV__MOSAIC__TOPO__BRIEF.html#aa9ccefebb5b6b38ca5a554713a97bedd", null ],
    [ "version", "structNV__MOSAIC__TOPO__BRIEF.html#a338ef14db2f06c5a83026ce9f35bc081", null ]
];