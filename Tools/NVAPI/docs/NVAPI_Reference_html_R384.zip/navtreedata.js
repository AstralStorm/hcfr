var NAVTREE =
[
  [ "NVAPI Reference Documentation (Developer)", "index.html", [
    [ "NVIDIA NVAPI", "index.html", "index" ],
    [ "Legal Notice", "legal.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", "globals_enum" ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"NvApiDriverSettings_8h.html",
"NvApiDriverSettings_8h.html#a49f32517cce0158eb041adc81536cbffa08440c1d4f637b2ee3ef2e03893ff97f",
"NvApiDriverSettings_8h.html#a8e75c074b5528d10e3e021b2d595719caf0a80868deda5b855db2b4198ee2ba1c",
"NvApiDriverSettings_8h.html#abe0a4a1603e82096f3bb0f6b257c390ba32f87f94e2a7097cb69324b80e695271",
"globals_d.html",
"group__dispcontrol.html#gae3219138dfba3ebc238c0fb69be2bdb3",
"group__drsapi.html#ga68dbe5987a8f530a0041ba94019b0ec0",
"group__dx.html#gga102df4d23c307c4376d55946e6ede4e7a7b5e090f6932effbfa3ae4e726a2d25d",
"group__gpu.html#ga8abdc45180c02890b05bef3771ad4bcb",
"group__gpu.html#ggac793e42a79ad0f9ccc4ec8b7cfdb021ca650f8f0a2a3f7b8418645dfe222f2f63",
"group__gsyncapi.html#ga610c98a0e061efdf098fdbc317861023",
"group__nvapifunctions.html#ga5b083676716a90156b9b634c69c7eea2",
"group__nvapistatus.html#gga12534f3b520256799842c0172e9afdf7ac5e05b7f7903360e51f277864c1dd21f",
"group__stereoapi.html#ga3490c7efdf58d95d736988f324af7f1e",
"group__vidio.html#ga0c3360c77760ccf575332895e5f32b86",
"group__vidio.html#ggae1f8ba4a323ebe9a5f20e6b7a37ae475a405ce559caae12d06aa45a8e1f44f982",
"nvShaderExtnEnums_8h.html",
"nvapi_8h.html#a359cd60df829a4914faa7b8a16280222a394892a5ea2e21cb6f6e304258c4fd5c",
"nvapi_8h.html#a8baa2c934eba8214cafc2feae1d47a7baf87f06d142ca3c345fb6bc22350d8c3f",
"nvapi_8h.html#ad5eb2fd72de1a3e77870f15fddb6301aa37ee7f79f62ae3a7b59316999e61d214",
"nvapi__lite__salstart_8h.html#a52a970a7109d111535df14e37317f6b0",
"nvapi__lite__salstart_8h.html#af61f78873dd73fce6b0cf59fa989c254",
"structNV__GET__CURRENT__SLI__STATE__V2.html#ac9666a9669db3cc600dbe1c31f89d47b",
"structNV__MOSAIC__TOPO__BRIEF.html#a0c35ffc94bc867ebd259e803c06e2806",
"struct__NVDRS__PROFILE__V1.html#a2af9b8f5304a5e330c6160617c91572d",
"struct__NV__COLOR__DATA__V1.html#a0fe69d1b8bc9fd39dd2b65dbddd724f3",
"struct__NV__GSYNC__STATUS__PARAMS__V2.html#ae839e0702bdf15c2ef5aac131132315d",
"struct__NV__POSITION.html#a31af81ad2e59aaff3143c0d73b3cff21"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';