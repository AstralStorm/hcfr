var structNV__GPU__PSTATE20__BASE__VOLTAGE__ENTRY__V1 =
[
    [ "bIsEditable", "structNV__GPU__PSTATE20__BASE__VOLTAGE__ENTRY__V1.html#a54d35105cb12f7df7a4e6153dff90fc5", null ],
    [ "domainId", "structNV__GPU__PSTATE20__BASE__VOLTAGE__ENTRY__V1.html#a632a77342a0cf37d57cce0e1c611e60b", null ],
    [ "reserved", "structNV__GPU__PSTATE20__BASE__VOLTAGE__ENTRY__V1.html#aed6d689acbb855760860b5e8796fc73c", null ],
    [ "volt_uV", "structNV__GPU__PSTATE20__BASE__VOLTAGE__ENTRY__V1.html#a332dfd8c11166bfa9f5f752a254bac77", null ],
    [ "voltDelta_uV", "structNV__GPU__PSTATE20__BASE__VOLTAGE__ENTRY__V1.html#a47f7304202f43d9c8ae121e59ae22583", null ]
];