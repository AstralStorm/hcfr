var structNV__DISPLAY__DRIVER__MEMORY__INFO__V1 =
[
    [ "availableDedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V1.html#a95099d66f55f0f6f4890df49b726b5a4", null ],
    [ "dedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V1.html#a7e94037ad7c1708ca33ccf5100057532", null ],
    [ "sharedSystemMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V1.html#aea78aa0de56774ef72b616f8697fa7e6", null ],
    [ "systemVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V1.html#ae9feb2bc5a6a826979eff66cb87abdc0", null ],
    [ "version", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V1.html#a2fb5e3b57568a910adc4f9c65a268801", null ]
];