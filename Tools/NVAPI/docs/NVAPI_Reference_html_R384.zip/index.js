var index =
[
    [ "About this Documentation", "documentation.html", null ],
    [ "System Requirements", "sysreq.html", null ],
    [ "Important NVAPI Concepts", "concepts.html", [
      [ "NvAPI Handles", "concepts.html#handles", null ],
      [ "Structure Versions Must be Initialized", "concepts.html#structureversions", null ],
      [ "Use a Static Link with Applications", "concepts.html#staticlink", null ]
    ] ],
    [ "Deprecation Warnings", "deprecated.html", null ]
];